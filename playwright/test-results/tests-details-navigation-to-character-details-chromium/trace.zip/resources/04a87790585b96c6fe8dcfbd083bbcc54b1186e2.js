"use strict";
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},n=(new Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="81b041b7-0e2a-5d6e-9dd6-bc32d5c7b849")}catch(e){}}();
(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8538],{118636:(e,t,n)=>{n.d(t,{II:()=>c,Ke:()=>g,NL:()=>u});var r=n(658584),i=n(99785),a=n(539737),o=n(851605),l=n(353564);let s=(0,o.createContext)(null);function c(e){let{variant:t,children:n}=e,i=(0,o.useMemo)(()=>Math.random().toString(36).slice(2),[]);return(0,r.jsx)(s.Provider,{value:(0,o.useMemo)(()=>({anonId:i,variant:t}),[t,i]),children:n})}let u=()=>(0,o.useContext)(s),d={[i.X.SIGNUP_VIEW_STATE]:{topic:l.Zf.LifecycleV0SignupViewState,action:"view"},[i.X.SIGNUP_VIEW_PAGE]:{topic:l.Zf.LifecycleV0SignupViewPage,action:"view"},[i.X.SIGNUP_PLAN_SELECTED]:{topic:l.Zf.LifecycleV0SignupPlanSelected,action:"select-plan"},[i.X.SIGNUP_CLICK_ELEMENT]:{topic:l.Zf.LifecycleV0SignupClickElement,action:"click"}},g=()=>{let e=u();return(0,o.useCallback)((t,n)=>{if(!e)return;let{variant:r,anonId:i}=e;a.co.track(t,{...n,variant:r});let o=d[t];(0,l.om)(o.topic,{metrics_object:{actor_id:i,actor_type:"visitor",action:o.action,object:"new"===r?"new-signup":"signup"},is_new_page:"new"===r,...n},"vercel-app")},[e])}},78264:(e,t,n)=>{n.d(t,{J:()=>a});var r=n(436832),i=n(173457);function a(){let e=(0,i.d2)()||void 0,{pathname:t,utm:n}=(0,r.ki)()||{},a=new URLSearchParams(window.location.search).get("gclid");if(!a){let e=localStorage.getItem("gclid");if(e){let{value:t,expiration:n}=JSON.parse(e);new Date(n)>new Date&&(a=t)}}return{sessionReferrer:e,landingPage:t,pageBeforeConversionPage:document.referrer,utm:{utmSource:n?.utm_source,utmMedium:n?.utm_medium,utmCampaign:n?.utm_campaign,utmTerm:n?.utm_term},...a&&{gclid:a}}}},154783:(e,t,n)=>{n.d(t,{E:()=>a});var r=n(736384),i=n.n(r);async function a(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:3;return i()(e,{randomize:!1,factor:1,minTimeout:t>=5?1e3:250,maxTimeout:t>=5?1001:251,retries:t})}},596113:(e,t,n)=>{n.d(t,{e:()=>i,j:()=>a});var r=n(651512);function i(e){if(!e)return null;let t=e in r.CODES?r.CODES[e]:e;return t in r.ERRORS?r.ERRORS[t]:null}function a(e){let t;if("string"!=typeof e)return null;try{t=JSON.parse(decodeURIComponent(e))}catch(e){return null}return t.message=i(t.code)||"Unknown error.",t}},504184:(e,t,n)=>{n.d(t,{Z:()=>r});function r(e){return new Promise(t=>{setTimeout(t,e)})}},731254:(e,t,n)=>{n.d(t,{Dg:()=>o,Ir:()=>a,PM:()=>r,YN:()=>i,jq:()=>l});let r={PLACEHOLDER:"placeholder",INPUT:"input",LOADING_EMAIL:"loading-email",LOADING_GITHUB:"loading-github",LOADING_GITLAB:"loading-gitlab",LOADING_BITBUCKET:"loading-bitbucket",LOADING_SAML:"loading-saml",LOADING_PASSKEY:"loading-passkey",VERIFYING_EMAIL:"verifying",VERIFYING_EMAIL_OTP:"verifying-otp",LOADING_EMAIL_OTP:"loading-otp",ERROR_EMAIL_OTP:"error-otp",SUCCESS:"success",ERROR:"error",ACCOUNT_NEEDS_VERIFY_SMS:"account-needs-verify",SELF_SERVE_VERIFICATION:"self-serve-verification"},i=[r.LOADING_GITHUB,r.LOADING_GITLAB,r.LOADING_BITBUCKET,r.LOADING_SAML,r.LOADING_EMAIL,r.LOADING_PASSKEY,r.LOADING_EMAIL_OTP],a={github:"GitHub login",gitlab:"GitLab login",bitbucket:"Bitbucket login",git:"Git login",saml:"Saml login",email:"Email login",passkey:"Passkey login","github-custom-host":"GitHub login"},o="/new?onboarding=true",l="/new"},608538:(e,t,n)=>{n.d(t,{YN:()=>y.YN,PM:()=>y.PM,aC:()=>Y});var r=n(851605),i=n(651512),a=n(723119),o=n(823986),l=n(408652),s=n(586845),c=n(64846),u=n(106693),d=n(853514),g=n.n(d),m=n(770713),f=n(737373),p=n(613209),h=n(966257),S=(n(139488),n(724149),n(375025)),w=n(118636),v=n(107061);let b=e=>(0,v.x)(e)&&"code"in e;var E=n(78264),y=n(731254),I=n(153092),_=n(716154),P=n(847570),O=n.n(P);let R=(e,t)=>`<!DOCTYPE html>
<html lang="en">
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <style>
    /*!normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css*/
    html {
      -webkit-text-size-adjust: 100%;
      height: -webkit-fill-available;
    }
    *,
    *:before,
    *:after {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      align-items: center;
      display: flex;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI',
        'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans',
        'Helvetica Neue', sans-serif;
      height: 100vh;
      width: 100vw;
      height: -webkit-fill-available;
      width: -webkit-fill-available;
      justify-content: center;
      max-height: 100vh;
      max-height: -webkit-fill-available;
      min-height: 100vh;
      min-height: -webkit-fill-available;
      padding: 0;
      -webkit-font-smoothing: antialiased;
      position: fixed;
      top: 0;
    }
    h1 {
      font-size: 1.5em;
      color: rgba(0, 0, 9);
      font-weight: 600;
      line-height: 32px;
      margin: 0 0 24px 0;
      text-align: center;
      letter-spacing: -0.47px;
    }
    p {
      color: rgba(0, 0, 9);
      font-weight: 400;
      font-size: 1rem;
      line-height: 1.5rem;
      margin: 0 0 24px 0;
      text-align: center;
    }
    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin: 0 auto;
    }
    .backup-redirect {
      font-size: 14px;
      color: #666;
      position: absolute;
      bottom: 0;
      animation: 0.2s ease 4s 1 delay;
      animation-fill-mode: both;
    }
    a {
      color: #333;
      display: inline;
    }
    .spinner-wrapper {
      height: 24px;
      width: 24px;
    }
    .spinner {
      position: relative;
      top: 50%;
      left: 50%;
      height: 24px;
      width: 24px;
    }
    .spinner-bar {
      -webkit-animation: spinner-spin 1.2s linear infinite;
      animation: spinner-spin 1.2s linear infinite;
      background: rgba(0, 0, 56);
      border-radius: 5px;
      height: 8%;
      left: -10%;
      position: absolute;
      top: -3.9%;
      width: 24%;
    }
    .spinner-bar:nth-child(1) {
      animation-delay: -1.2s;
      transform: rotate(0.0001deg) translate(146%);
    }
    .spinner-bar:nth-child(2) {
      animation-delay: -1.1s;
      transform: rotate(30deg) translate(146%);
    }
    .spinner-bar:nth-child(3) {
      animation-delay: -1s;
      transform: rotate(60deg) translate(146%);
    }
    .spinner-bar:nth-child(4) {
      animation-delay: -0.9s;
      transform: rotate(90deg) translate(146%);
    }
    .spinner-bar:nth-child(5) {
      animation-delay: -0.8s;
      transform: rotate(120deg) translate(146%);
    }
    .spinner-bar:nth-child(6) {
      animation-delay: -0.7s;
      transform: rotate(150deg) translate(146%);
    }
    .spinner-bar:nth-child(7) {
      animation-delay: -0.6s;
      transform: rotate(180deg) translate(146%);
    }
    .spinner-bar:nth-child(8) {
      animation-delay: -0.5s;
      transform: rotate(210deg) translate(146%);
    }
    .spinner-bar:nth-child(9) {
      animation-delay: -0.4s;
      transform: rotate(240deg) translate(146%);
    }
    .spinner-bar:nth-child(10) {
      animation-delay: -0.3s;
      transform: rotate(270deg) translate(146%);
    }
    .spinner-bar:nth-child(11) {
      animation-delay: -0.2s;
      transform: rotate(300deg) translate(146%);
    }
    .spinner-bar:nth-child(12) {
      animation-delay: -0.1s;
      transform: rotate(330deg) translate(146%);
    }
    @keyframes spinner-spin {
      0% {
        opacity: 0.5;
      }
      100% {
        opacity: 0.1;
      }
    }
    @keyframes delay {
      from {
        transform: translateY(72px);
      }
      to {
        transform: none;
      }
    }
    ${"dark"===t?`
          body {
            color: rgb(237, 237, 237);
            background: #000;
          }
          h1 {
            color: rgb(237, 237, 237);
          }
          p {
            color: #ddd;
          }
          .spinner-bar {
            background: #eee;
          }
          `:""}
  </style>
  <body>
    <div class="container">
      <h1>Authenticating</h1>
      <p>Vercel is validating your identity.<br />Please wait...</p>
      <div class="spinner-wrapper">
        <div class="spinner">
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
          <div class="spinner-bar"></div>
        </div>
      </div>
      <p class="backup-redirect">
        If you aren't automatically redirected,
        <a href="${O()(e)}">click here</a>
      </p>
    </div>
  </body>
</html>`;var L=n(584095),N=n(539737),A=n(99785),M=n(847881),T=n(973180),k=n(721734),C=n(460272),U=n(618735),D=n(154783);async function x(e,t){if("signup"===e&&t?.startsWith("/turborepo"))try{let e=await (0,T.P)();if(!e.user)return;if(!(await fetch("/api/turborepo-signup",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:e.user.email,heapUserId:(0,k.lM)(),heapIdentity:(0,k.uu)()})})).ok)throw Error("An unexpected error. Please try again later.")}catch{}}async function G(e){e&&e.length>0&&await (0,D.E)(()=>(0,p.Io)(o.zh,{method:"PATCH",body:{name:O()(e)}}))}async function j(e){["loading-github","loading-gitlab","loading-bitbucket"].includes(e)&&await (0,U.xb)({provider:e.split("-")[1],namespaceId:null})}function $(e){let t=new URL("/oauth/git",window.location.origin),n=e instanceof URLSearchParams?e:new URLSearchParams((0,M.c)(e));return t.search=n.toString(),t.toString()}function V(e){let{authType:t,baseUrl:n,mode:r,next:i,useRedirect:a=!1,params:l}=e,{next:s,callbackParams:c,...u}=l,d=i?.match(/^\/(?<scope>[^/]+)/)?.groups?.scope||null,g=$({next:a?s??i:s,scope:d,...c}),m="saml"===t.toLowerCase()?o.fr:o.OK,f=function(e){if(!e)return{};let{sessionReferrer:t,landingPage:n,pageBeforeConversionPage:r,utm:i}=e,a={...i.utmSource&&{utmSource:i.utmSource},...i.utmMedium&&{utmMedium:i.utmMedium},...i.utmCampaign&&{utmCampaign:i.utmCampaign},...i.utmTerm&&{utmTerm:i.utmTerm}},o=Object.keys(a).length>0;return{...t&&{sessionReferrer:t},...n&&{landingPage:n},...r&&{pageBeforeConversionPage:r},...o&&{...a},...e.gclid&&{gclid:e.gclid}}}((0,E.J)());return`${m}${n}${(0,M.c)({mode:r,next:g,...u,..."saml"!==t?f:{},..."saml"!==t&&l.oppId?{opportunityId:l.oppId}:{}})}`}n(504184);var J=n(64624);let Y=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"login",t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},{state:n,dispatch:d,saveInput:v,verifySMS:P}=(0,L.F)(t),O=(0,l.t)(),M=(0,s.usePathname)(),T=(0,J.j)(),k=(0,c.useSearchParams)(),U=(0,S.Z)(k?.get("next")),D=(0,w.NL)(),Y=(0,r.useRef)(g()),F=(0,r.useRef)(t);(0,r.useEffect)(()=>{F.current=t},[t]);let{data:H}=(0,f.a)(),B=H?.user;!function(e,t){let n=(0,l.t)(),i=(0,s.usePathname)(),a=(0,c.useSearchParams)();(0,r.useEffect)(()=>{if(!a)return;let r=a.get(e);if(r&&i&&r&&!t(r)){let t=new URLSearchParams(a);t.delete(e),n.replace(`${i}?${t.toString()}`,void 0,{shallow:!0})}},[i,a,e,t,n])}("next",e=>!!(0,S.Z)(e));let{popup:z,openPopup:W,closePopup:Z}=function(e,t){let n=(0,r.useRef)(null),{theme:i}=(0,I.F)();(0,r.useEffect)(()=>()=>{n.current&&n.current.close(),n.current=null},[]);let a=(0,r.useCallback)((r,a)=>{n.current||(n.current=new _.Z({id:e,url:r,callbacks:{onOpen:()=>{t.onOpen?.(a)},onAbort:()=>{n.current=null,t.onAbort?.(a)},onClose:()=>{n.current=null,t.onClose?.(a)},onBlocked:()=>{n.current=null,t.onBlocked?.(a)}},prerenderHtml:R(r,i)}),n.current.open())},[e,t,i]),o=(0,r.useCallback)(function(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];n.current&&n.current.close(e),n.current=null},[]);return{popup:n.current,openPopup:a,closePopup:o}}("vercel-login-popup",{onOpen:e=>{let{authType:t}=e;d({loginState:y.PM[`LOADING_${t.toUpperCase()}`]})},onAbort:()=>{d({loginState:y.PM.INPUT})},onClose:()=>{d({loginState:y.PM.INPUT})},onBlocked:e=>{let{authType:t,redirectUrl:n}=e;d({loginState:y.PM[`LOADING_${t.toUpperCase()}`]}),window.location.assign(n)}});(0,r.useEffect)(()=>{if(!z&&(!("isReady"in O)||O.isReady)){if(k?.get("loginType")==="saml"&&"1"===k.get("confirmed")){d({loginState:y.PM.LOADING_SAML});let e=new URLSearchParams(k);T&&!e.has("teamSlug")&&e.set("teamSlug",T),T&&!U&&e.set("next",`/${T}`);let t=`${$(e)}`;O.push(t);return}if(k?.get("origin")==="saml"&&"/login"===M){d({loginState:y.PM.LOADING_SAML}),O.push(`/teams/connect?${k.toString()}`);return}O.query.token||n.loginState!==y.PM.PLACEHOLDER||d({loginState:y.PM.INPUT})}},[T,k,O,U,z,d,M,n.loginState]);let K=(0,r.useRef)(void 0);function q(n,r){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};K.current=n,d({loginError:null,loginState:y.PM[`LOADING_${n.toUpperCase()}`]});let a={authType:n,baseUrl:r,params:i,mode:e,next:U},o=V(a),l=V({...a,useRedirect:!0});if(!t.useRedirect){Z(!0),W(o,{redirectUrl:l,authType:n});return}window.location.href=l}function X(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};q(e,"github"===e?"/login-with-github":`/${e}/connect`,t)}async function Q(){let e,t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};d({loginState:y.PM.LOADING_PASSKEY,loginError:null});let n=await fetch("/api/auth/webauthn/options"),r=await n.json();if(!("challenge"in r)){d({loginState:y.PM.ERROR,loginError:(0,a.normalizeError)(r.error)});return}try{e=await (0,u.oz)(r)}catch(e){d({loginState:y.PM.ERROR,loginError:{message:"Login with Passkey took too long or was cancelled. Please try again."}});return}let i=new URLSearchParams;t.callbackParams?.ssoToken&&i.set("ssoToken",t.callbackParams.ssoToken);let o=await fetch(`/api/auth/webauthn/verify?${i.toString()}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)});if(!(await o.json()).verified){d({loginState:y.PM.ERROR,loginError:{message:"Login with Passkey failed. Please try again."}});return}await er({...t,provider:"passkey",showAuthSuccess:!1})}async function ee(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=t.email??n.email;if(!r){d({loginState:y.PM.ERROR,loginError:{code:"",message:"Please enter an email address."}});return}Y.current();let l=new AbortController;Y.current=()=>{l.abort()};try{d({loginState:y.PM.LOADING_EMAIL,loginError:null,email:r});{let n=`${o.OK}/email`,{token:i}=await (0,p.Io)(n,{method:"POST",body:JSON.stringify({...t,attribution:(0,E.J)(),mode:e,email:r}),headers:{"Content-Type":"application/json"},throwOnHTTPError:!0});!function(e,t){try{if("signup"!==e||"email"!==t)return;N.co.track(A.X.SIGN_UP_INTENT,{source:y.Ir.email})}catch{}}(e,"email"),d({loginState:y.PM.VERIFYING_EMAIL_OTP,token:i,email:r});return}}catch(t){if(t instanceof Error&&"AbortError"===t.name)return;if(b(t)&&t.code===i.CODES.ACCOUNT_NEEDS_VERIFY)return P();let e=(0,a.normalizeError)(t);"rate_limited"===e.code&&(e.message=e.message.replace(/ \(.*\)\.$/,".")),d({loginState:y.PM.ERROR_EMAIL_OTP,loginError:e})}}async function et(e){try{d({loginState:y.PM.LOADING_EMAIL_OTP,loginError:null});let t=await (0,p.Io)(`${o.OK}/email/verify`,{body:JSON.stringify(e),headers:{"Content-Type":"application/json"},method:"POST",throwOnHTTPError:!0});delete globalThis.__loggedIn,await er({...t,provider:"email",showAuthSuccess:!0})}catch(t){if(b(t)&&t.code===i.CODES.ACCOUNT_NEEDS_VERIFY)return P();let e=(0,a.normalizeError)(t);"rate_limited"===e.code&&(e.message=e.message.replace(/ \(.*\)\.$/,".")),d({loginState:y.PM.ERROR_EMAIL_OTP,loginError:e})}}async function en(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=t.teamSlug??n.teamSlug??T;if(!r)return d({loginState:y.PM.ERROR,loginError:{code:"",message:"Please enter a Team slug."}});q("saml","",{next:U||`/${r}`,...t,teamId:r,mode:e})}async function er(r){let{provider:i,showAuthSuccess:a,...o}=r;Z(!0),o.mode??=e,o.teamSlug??=n.teamSlug??T??void 0,o.next??=U,function(e){let{source:t,variant:n}=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};try{let r=t?y.Ir[t]:void 0;"signup"===e?(N.co.track(A.X.CREATE_ACCOUNT,{source:r,variant:n}),N.co.track(A.X.SIGN_UP,{source:r,variant:n}),(0,C.O)({eventName:"create_account",metadata:{source:r||""}})):"login"===e&&N.co.track(A.X.LOGIN,{source:r})}catch{}}(o.mode,{source:i,variant:D?.variant}),delete globalThis.__loggedIn,await (0,h.Hu)();let l=function(){let e=(0,m.bR)();return o.next?o.next:o.teamSlug?`/${o.teamSlug}`:e?`/${e}`:B?`/${B.username}`:"signup"===o.mode?y.jq:"/dashboard"}();if(x(o.mode,l),"signup"===o.mode&&await Promise.all([G(o.patchedSignupAccountName),j(n.loginState)]),a&&d({loginState:y.PM.SUCCESS}),F.current.onAuthenticated){F.current.onAuthenticated();return}t.skipDefaultRedirectOnSignup||("signup"===o.mode&&(l=y.Dg),setTimeout(()=>{window.location.href=new URL(l,window.location.href).href},300))}return!function(e,t){let n=(0,r.useRef)(t);(0,r.useEffect)(()=>{n.current=t},[t]);let i=(0,r.useCallback)(t=>{if(!e)return;let r=function(e,t){if(!t.source||t.source!==e?.popup||!t.data||"object"!=typeof t.data)return null;let n=t.data;return"vercel-verify-auth"!==n.source?null:n}(e,t);if(!r)return;let i=e.popup?.location.search,a=i?new URLSearchParams(i):null;n.current(r,a)},[e]);(0,r.useEffect)(()=>(window.addEventListener("message",i),()=>{window.removeEventListener("message",i)}),[i])}(z,async(e,t)=>{if(e.close){Z(!0),t?.get("origin")==="saml"&&O.push(`/teams/connect?${t.toString()}`);return}if(e.loginError&&Z(!0),e.loginState||e.loginError){let t={};e.loginState&&(t.loginState=e.loginState),e.loginError&&(t.loginError=e.loginError),d(t)}if(!e.success){d({loginState:e.loginState,loginError:e.loginError}),F.current.onError?.();return}let n=t?.get("next");n=n?decodeURIComponent(n):null,await er({next:e.next??n,provider:K.current??void 0,showAuthSuccess:!0})}),{saveInput:v,cancelLogin:function(){if(Y.current(),d({loginState:y.PM.INPUT,loginError:null}),t.skipRouterRedirectOnCancel||!M)return;let e=new URLSearchParams;U&&e.set("next",U);let n=k?.get("isRequestAccess");n&&e.set("isRequestAccess",n);let r=k?.get("teamName");r&&e.set("teamName",r),O.replace(`${M}?${e.toString()}`)},loginWithEmail:ee,loginWithPasskey:Q,loginWithSAML:en,loginWithGitHub:function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return X("github",e)},loginWithGitLab:function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return X("gitlab",e)},loginWithBitbucket:function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return X("bitbucket",e)},loginWithGit:X,loginWithOneTimePassword:et,state:n,dispatch:d,mode:e}}},584095:(e,t,n)=>{n.d(t,{F:()=>d,w:()=>c});var r=n(64846),i=n(651512),a=n(851605),o=n(596113),l=n(731254);function s(e,t){return Object.keys(t).some(n=>t[n]!==e[n])?{...e,...t}:e}function c(e){if(!e)return!1;let t=e.split(".");if(3!==t.length)return!1;try{return JSON.parse(atob(t[1])),!0}catch{return!1}}function u(e){let t=e?.get("token")??void 0;if(c(t)){let{email:e,error:n}=function(e){try{if(!e)throw Error();let t=JSON.parse(atob(e.split(".")[1])),n=Date.now()/1e3;if(t.exp<n)return{email:t.sub,error:{code:"used_or_expired",message:i.ERRORS.used_or_expired}};return{email:t.sub,error:null}}catch{return{email:void 0,error:{code:"invalid_jwt",message:i.ERRORS.invalid_jwt}}}}(t);return{token:t,email:e,loginState:n?l.PM.ERROR_EMAIL_OTP:l.PM.VERIFYING_EMAIL_OTP,loginError:n,isLoading:!1}}return{loginState:l.PM.PLACEHOLDER,loginError:null,isLoading:!0}}function d(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=(0,r.useSearchParams)(),[n,i]=(0,a.useReducer)(s,{...u(t),...e.defaultState});return(0,a.useEffect)(()=>{let e=t?.get("loginError");e?i({loginState:l.PM.ERROR,loginError:(0,o.j)(e)}):t?.has("token")&&i(u(t))},[t]),(0,a.useEffect)(()=>{let e=n.loginState===l.PM.PLACEHOLDER||l.YN.includes(n.loginState);n.isLoading&&!e&&i({isLoading:e})},[n.loginState,n.isLoading]),{state:n,dispatch:i,saveInput:function(e,t){n.loginState===l.PM.ERROR?i({[e]:t,loginError:null}):i({[e]:t})},verifySMS:function(){n.email&&i({loginState:l.PM.ACCOUNT_NEEDS_VERIFY_SMS})}}}},460272:(e,t,n)=>{n.d(t,{O:()=>a});var r=n(269194),i=n(315773);function a(e){if(Number.isNaN(e.value))return;let t={events:[{user:{userID:(0,i.sq)()??""},time:Date.now(),...e}]};(0,r.Z)("/api/stream/internal/statsig",t)}},315773:(e,t,n)=>{n.d(t,{Lb:()=>o,sq:()=>l});var r=n(693036),i=n(61610),a=n(673121);function o(e){return e?(0,a.$m)(e):(0,a.D9)()}function l(){let e="1"===(0,r.ej)("isLoggedIn"),t=(0,r.ej)(i.QI);return t&&"undefined"!==t&&e===t.startsWith(a.nk)?t:null}},587298:(e,t,n)=>{n.d(t,{CY:()=>l,QA:()=>m,dl:()=>g,s3:()=>c,wc:()=>u});var r,i=n(851605);!function(e){e.Source="utm_source",e.Medium="utm_medium",e.Campaign="utm_campaign",e.Content="utm_content",e.Term="utm_term"}(r||(r={}));let a=new Set(Object.values(r)),o={utm_source:"",utm_medium:"",utm_campaign:"",utm_content:"",utm_term:""};function l(e){let t=Object.entries(e).filter(e=>{let[t]=e;return"string"==typeof t&&a.has(t)}).reduce((e,t)=>{let[n,r]=t;return e[n]=r,e},{});return{...o,...t}}function s(){let e=d();try{let t=new URL(e).searchParams;return Object.fromEntries(t.entries())}catch{return{}}}function c(){let e=s();return(0,i.useMemo)(()=>l(e),[e])}function u(){let e=s(),[t,n]=(0,i.useState)();return(0,i.useEffect)(()=>{if(e.gclid){let t=new Date;t.setDate(t.getDate()+90);let r={value:e.gclid,expiration:t};localStorage.setItem("gclid",JSON.stringify(r)),n(e.gclid)}else{let e=localStorage.getItem("gclid");if(e){let t=JSON.parse(e);new Date(t.expiration)>new Date&&n(t.value)}}},[e.gclid]),t}function d(){let[e,t]=(0,i.useState)("");return(0,i.useEffect)(()=>{t("localhost"===window.location.hostname?`https://vercel.com/dev-mode${window.location.pathname}${window.location.search}`:window.location.toString())},[]),e}function g(){let e=c(),t=u(),n=d(),r=function(){let[e,t]=(0,i.useState)("undefined"!=typeof document?document.referrer:"");return(0,i.useEffect)(()=>{t(document.referrer)},[]),e}(),{firstReferrer:a}=m(r);return(0,i.useMemo)(()=>({utm:e,gclid:t,url:n,referrer:r,firstReferrer:a}),[e,t,n,r,a])}let m=e=>{if("undefined"==typeof localStorage)return{firstReferrer:""};let t=JSON.parse(localStorage.getItem("referrers")||'{"firstReferrer": ""}');return""!==t.firstReferrer&&t.firstReferrer||(t.firstReferrer=e,localStorage.setItem("referrers",JSON.stringify(t))),{firstReferrer:t.firstReferrer}}},721734:(e,t,n)=>{n.d(t,{WM:()=>i,lM:()=>a,uu:()=>o});var r=n(851605);function i(){return{userId:function(){let[e,t]=(0,r.useState)();return(0,r.useEffect)(()=>{t(a())},[]),e}(),identity:function(){let[e,t]=(0,r.useState)();return(0,r.useEffect)(()=>{t(o())},[]),e}()}}function a(){if(window?.heap&&"string"==typeof window.heap.userId)return window.heap.userId}function o(){if(window?.heap&&"string"==typeof window.heap.identity)return window.heap.identity}},436832:(e,t,n)=>{n.d(t,{$M:()=>d,ay:()=>c,ki:()=>g});var r=n(851605),i=n(461949),a=n.n(i),o=n(64846),l=n(587298);let s="lpid";function c(){(0,r.useEffect)(()=>{g()},[])}let u=()=>{let e=JSON.parse(sessionStorage.getItem("uval")||'{"currentUrl": "", "prevUrl": ""}');return window.location.href!==e.currentUrl&&(e.prevUrl=e.currentUrl,e.currentUrl=window.location.href,sessionStorage.setItem("uval",JSON.stringify(e))),{currentUrl:e.currentUrl||window.location.href,prevUrl:e.prevUrl}};function d(){let e=(0,o.usePathname)();(0,r.useEffect)(()=>{u()},[e])}function g(){let e=sessionStorage.getItem(s);try{null===e&&sessionStorage.setItem(s,window.location.href);let t=e||window.location.href,{pathname:n,searchParams:r}=a()(t,{require_protocol:!0})?new URL(t):t.startsWith("/")?new URL(t,window.location.origin):new URL(window.location.href),i=Object.fromEntries(r.entries()),o=(0,l.CY)(i),c=JSON.parse(localStorage.getItem("utmValues")||'{"currentUtm": {}, "prevUtm": {}}');return(0===Object.keys(c.prevUtm).length||Object.values(c.prevUtm).every(e=>""===e))&&(c.prevUtm=o),c.currentUtm=o,localStorage.setItem("utmValues",JSON.stringify(c)),{pathname:n,href:t,queryParams:i,utm:o,prevUtm:c.prevUtm}}catch(e){return console.error(e),null}}},710868:(e,t,n)=>{var r;n.d(t,{Zf:()=>r,lA:()=>i}),function(e){e.TemplateClonedSimple="vercel_templates.v0.template_cloned_simple",e.VercelActivity="vercel_app.v0.vercel_activity",e.ContactSalesFormFill="vercel_contact_sales.v0.contact_sales_form_fill"}(r||(r={}));let i=async(e,t)=>fetch("/api/stream/internal",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic:e,record:t})}).catch(()=>null)},173457:(e,t,n)=>{let r;n.d(t,{IF:()=>d,d2:()=>f});var i=n(148506),a=n(851605),o=n(408652),l=n(64846),s=n(254764),c=n(587298),u=n(710868);function d(){var e;let t=(0,a.useRef)({}),n=(0,a.useRef)(!1),{user:r,team:i,isLoading:c,isTeam:u}=(0,s.m)();n.current=r?.email?.endsWith("@zeit.pub")??!1;let d=(0,o.t)(),m=(0,l.useParams)(),f=(0,l.useSearchParams)();return t.current={projectId:m?.projectId??f?.get("projectId")??(Array.isArray(e=d.query.project)?e[0]:e),userId:r?.uid,teamId:u?i?.id:null,userRole:u?i?.membership?.role:null,billingPlan:u?i?.billing?.plan:r?.billing?.plan,route:d.pathname},{isReady:!c,track:(0,a.useRef)((e,r)=>n.current?Promise.resolve():g(e,{...t.current,...r})).current}}let g=async(e,t)=>{let{projectId:n,deploymentId:a,teamId:o,userRole:l,billingPlan:s,userId:c,route:d,...g}=t;await (0,u.lA)(u.Zf.VercelActivity,{session_id:(r||(r=sessionStorage.getItem("sid")??void 0)||(r=(0,i.Z)(),sessionStorage.setItem("sid",r)),r),project_id:n,deployment_id:a,user_id:c,team_id:o,user_role:l,billing_plan:s,origin:window.origin,path:window.location.pathname,referrer:document.referrer||null,vercel_app:"vercel.com",action:e,user_agent:navigator.userAgent,browser_width:"number"==typeof window.innerWidth?Math.round(window.innerWidth):null,browser_height:"number"==typeof window.innerHeight?Math.round(window.innerHeight):null,meta:JSON.stringify(g),session_referrer:f(),route:d})},m="srid";function f(){let e=sessionStorage.getItem(m);return null===e?(sessionStorage.setItem(m,document.referrer||""),document.referrer):e?((0,c.QA)(e),e):null}}}]);
//# debugId=81b041b7-0e2a-5d6e-9dd6-bc32d5c7b849
